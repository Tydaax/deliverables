=== VW Cleaning Company ===
Contributors: VWthemes
Tags: left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, sticky-post, full-width-template, theme-options,post-formats, translation-ready, threaded-comments, accessibility-ready, rtl-language-support, blog, portfolio, e-commerce
Requires at least: 4.8
Tested up to: 5.2.2
Requires PHP: 7.2.14
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

VW cleaning company is a premium order theme with huge demand in the online international market for the cleaning services. Because of its special features and characteristics, it has become an essential house cleaning services theme with the prime focus on house and apartment cleaning businesses. 

== Description ==

VW cleaning company is a premium order theme with huge demand in the online international market for the cleaning services. Because of its special features and characteristics, it has become an essential house cleaning services theme with the prime focus on house and apartment cleaning businesses. This theme is not only modern and clean but is thoroughly professional and has been nicely created for a fine presentation of the business related to the cleaning services and also the spread of such business to the genuine and potential customers. VW cleaning company is minimal, elegant as well as sophisticated plus it has some exotic features like customization and personal options, clean code, Bootstrap framework and CTA[ call to action button] besides being retina ready, translation ready, multipurpose and responsive to different screens. It is accompanied with a testimonial section and has optimization codes plus faster page load time. All these features make it a numero uno for any company that deals with the cleaning services sector. There is no need of programming skills to use VW cleaning company theme and the advanced developers also go well with this one. It is good for cleaning service companies, maid service companies, maintenance and general service company and also suitable for other companies in the corporate category. 

== Changelog ==

= 0.1 =
* Initial version released.

= 0.2 =
* Added Accessibility Ready Tag.

== Resources ==

VW Cleaning Company WordPress Theme, Copyright 2019 VWthemes
VW Cleaning Company is distributed under the terms of the GNU GPL.

Theme is Built using the following resource bundles.

* CSS bootstrap.css
-- Copyright 2011-2018 The Bootstrap Authors
-- https://github.com/twbs/bootstrap/blob/master/LICENSE
    
* JS bootstrap.js
-- Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
-- https://github.com/twbs/bootstrap/blob/master/LICENSE

* Free to use and abuse under the MIT license.
-- http://www.opensource.org/licenses/mit-license.php
-- font-awesome.css and fonts folder
Font Awesome 5.0.0 by @davegandy - http://fontawesome.io - @fontawesome
-- License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

* Customizer Pro, Copyright 2016 © Justin Tadlock.
License: All code, unless otherwise noted, is licensed under the GNU GPL, version 2 or later.
Source: https://github.com/justintadlock/trt-customizer-pro

* Theme Typography, Copyright 2016 © Justin Tadlock.
License: All code, unless otherwise noted, is licensed under the GNU GPL, version 2 or later.
Source: https://github.com/justintadlock/customizer-typography

* Pexels Images, 
License: CC0 1.0 Universal (CC0 1.0)
Source: https://www.pexels.com/photo-license/

Header Image, Copyright Nathan Cowley
License: CC0 1.0 Universal (CC0 1.0)
Source: https://www.pexels.com/photo/man-in-blue-crew-neck-shirt-634007/

Feature Image, Copyright Nathan Cowley
License: CC0 1.0 Universal (CC0 1.0)
Source: https://www.pexels.com/photo/man-in-gray-shirt-cleaning-clear-glass-wall-near-sofa-713297/

Feature Image, Copyright rawpixel.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://www.pexels.com/photo/person-using-mop-on-floor-1321730/

* All the icons taken from genericons licensed under GPL License.
http://genericons.com/

== Theme Documentation ==
Documentation : https://www.vwthemesdemo.com/docs/free-vw-cleaning-company/